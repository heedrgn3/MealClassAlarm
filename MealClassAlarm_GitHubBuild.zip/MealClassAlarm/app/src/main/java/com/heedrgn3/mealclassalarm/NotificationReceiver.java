package com.heedrgn3.mealclassalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.time.LocalDate;

public class NotificationReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int g1 = AppPrefs.getInt(context, AppPrefs.KEY_GRADE_1_COUNT, 9);
        int g2 = AppPrefs.getInt(context, AppPrefs.KEY_GRADE_2_COUNT, 9);
        int g3 = AppPrefs.getInt(context, AppPrefs.KEY_GRADE_3_COUNT, 9);
        LocalDate startDate = AppPrefs.getStartDate(context);
        int offset = MealOrderCalculator.getWeekOffset(startDate, LocalDate.now());

        String body = MealOrderCalculator.makeNotificationText(g1, g2, g3, offset);
        NotificationHelper.showMealOrderNotification(context, "이번 주 급식 입장 순서", body);

        AlarmScheduler.scheduleNext(context);
    }
}
