package com.heedrgn3.mealclassalarm;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1001;

    private EditText grade1Input;
    private EditText grade2Input;
    private EditText grade3Input;
    private TextView startDateText;
    private TextView alarmTimeText;
    private Spinner alarmDaySpinner;
    private CheckBox enabledCheckBox;
    private TextView previewText;

    private LocalDate selectedStartDate;
    private LocalTime selectedAlarmTime;
    private int selectedAlarmDayOfWeek; // 1=Mon ... 7=Sun

    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.KOREA);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.createChannel(this);
        requestNotificationPermissionIfNeeded();
        loadSavedValues();
        setContentView(createContentView());
        updatePreview();
    }

    private void loadSavedValues() {
        selectedStartDate = AppPrefs.getStartDate(this);
        selectedAlarmDayOfWeek = AppPrefs.getInt(this, AppPrefs.KEY_ALARM_DAY_OF_WEEK, 1);
        int hour = AppPrefs.getInt(this, AppPrefs.KEY_ALARM_HOUR, 8);
        int minute = AppPrefs.getInt(this, AppPrefs.KEY_ALARM_MINUTE, 0);
        selectedAlarmTime = LocalTime.of(hour, minute);
    }

    private View createContentView() {
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(30));
        scrollView.addView(root);

        TextView title = new TextView(this);
        title.setText("반급식 알림");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("각 학년 반 수를 설정하면 매주 한 반씩 밀어서 3반 단위로 알려줍니다.");
        subtitle.setTextSize(15);
        subtitle.setPadding(0, dp(8), 0, dp(18));
        root.addView(subtitle, matchWrap());

        grade1Input = makeNumberInput(AppPrefs.getInt(this, AppPrefs.KEY_GRADE_1_COUNT, 9));
        grade2Input = makeNumberInput(AppPrefs.getInt(this, AppPrefs.KEY_GRADE_2_COUNT, 9));
        grade3Input = makeNumberInput(AppPrefs.getInt(this, AppPrefs.KEY_GRADE_3_COUNT, 9));
        root.addView(makeLabel("1학년 반 수"));
        root.addView(grade1Input);
        root.addView(makeLabel("2학년 반 수"));
        root.addView(grade2Input);
        root.addView(makeLabel("3학년 반 수"));
        root.addView(grade3Input);

        startDateText = makeBoxText("기준 시작일: " + selectedStartDate.format(dateFormatter));
        startDateText.setOnClickListener(v -> showDatePicker());
        root.addView(makeLabel("기준 시작일"));
        root.addView(startDateText);

        alarmDaySpinner = new Spinner(this);
        String[] days = {"월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, days);
        alarmDaySpinner.setAdapter(adapter);
        alarmDaySpinner.setSelection(Math.max(0, Math.min(6, selectedAlarmDayOfWeek - 1)));
        alarmDaySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedAlarmDayOfWeek = position + 1;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        root.addView(makeLabel("알림 요일"));
        root.addView(alarmDaySpinner);

        alarmTimeText = makeBoxText("알림 시간: " + formatTime(selectedAlarmTime));
        alarmTimeText.setOnClickListener(v -> showTimePicker());
        root.addView(makeLabel("알림 시간"));
        root.addView(alarmTimeText);

        enabledCheckBox = new CheckBox(this);
        enabledCheckBox.setText("매주 알림 켜기");
        enabledCheckBox.setTextSize(16);
        enabledCheckBox.setChecked(AppPrefs.getBoolean(this, AppPrefs.KEY_ALARM_ENABLED, true));
        root.addView(enabledCheckBox);

        Button saveButton = new Button(this);
        saveButton.setText("설정 저장");
        saveButton.setOnClickListener(v -> saveSettings());
        root.addView(saveButton, matchWrapWithTopMargin(12));

        Button testButton = new Button(this);
        testButton.setText("지금 테스트 알림 보내기");
        testButton.setOnClickListener(v -> sendTestNotification());
        root.addView(testButton, matchWrapWithTopMargin(8));

        previewText = makeBoxText("");
        previewText.setTextSize(16);
        previewText.setTypeface(Typeface.MONOSPACE);
        root.addView(makeLabel("이번 주 순서 미리보기"));
        root.addView(previewText);

        Button refreshButton = new Button(this);
        refreshButton.setText("미리보기 새로고침");
        refreshButton.setOnClickListener(v -> updatePreview());
        root.addView(refreshButton, matchWrapWithTopMargin(8));

        TextView note = new TextView(this);
        note.setText("※ 10반 이상은 헷갈리지 않게 8,9,10처럼 쉼표로 표시됩니다.\n※ 기기 절전 상태에서는 알림이 몇 분 늦을 수 있습니다.");
        note.setTextSize(13);
        note.setPadding(0, dp(18), 0, 0);
        root.addView(note);

        return scrollView;
    }

    private void showDatePicker() {
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    selectedStartDate = LocalDate.of(year, month + 1, dayOfMonth);
                    startDateText.setText("기준 시작일: " + selectedStartDate.format(dateFormatter));
                    updatePreview();
                },
                selectedStartDate.getYear(),
                selectedStartDate.getMonthValue() - 1,
                selectedStartDate.getDayOfMonth()
        );
        dialog.show();
    }

    private void showTimePicker() {
        TimePickerDialog dialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    selectedAlarmTime = LocalTime.of(hourOfDay, minute);
                    alarmTimeText.setText("알림 시간: " + formatTime(selectedAlarmTime));
                },
                selectedAlarmTime.getHour(),
                selectedAlarmTime.getMinute(),
                true
        );
        dialog.show();
    }

    private void saveSettings() {
        int g1 = readClassCount(grade1Input, "1학년");
        int g2 = readClassCount(grade2Input, "2학년");
        int g3 = readClassCount(grade3Input, "3학년");
        if (g1 <= 0 || g2 <= 0 || g3 <= 0) return;

        boolean enabled = enabledCheckBox.isChecked();
        AppPrefs.saveSettings(
                this,
                g1,
                g2,
                g3,
                selectedStartDate,
                selectedAlarmDayOfWeek,
                selectedAlarmTime.getHour(),
                selectedAlarmTime.getMinute(),
                enabled
        );

        if (enabled) {
            AlarmScheduler.scheduleNext(this);
            Toast.makeText(this, "저장 완료. 매주 알림을 예약했습니다.", Toast.LENGTH_SHORT).show();
        } else {
            AlarmScheduler.cancel(this);
            Toast.makeText(this, "저장 완료. 알림은 꺼져 있습니다.", Toast.LENGTH_SHORT).show();
        }
        updatePreview();
    }

    private void sendTestNotification() {
        int g1 = readClassCount(grade1Input, "1학년");
        int g2 = readClassCount(grade2Input, "2학년");
        int g3 = readClassCount(grade3Input, "3학년");
        if (g1 <= 0 || g2 <= 0 || g3 <= 0) return;

        int offset = MealOrderCalculator.getWeekOffset(selectedStartDate, LocalDate.now());
        String text = MealOrderCalculator.makeNotificationText(g1, g2, g3, offset);
        NotificationHelper.showMealOrderNotification(this, "이번 주 급식 입장 순서", text);
    }

    private void updatePreview() {
        if (previewText == null) return;
        int g1 = safeParse(grade1Input, AppPrefs.getInt(this, AppPrefs.KEY_GRADE_1_COUNT, 9));
        int g2 = safeParse(grade2Input, AppPrefs.getInt(this, AppPrefs.KEY_GRADE_2_COUNT, 9));
        int g3 = safeParse(grade3Input, AppPrefs.getInt(this, AppPrefs.KEY_GRADE_3_COUNT, 9));
        int offset = MealOrderCalculator.getWeekOffset(selectedStartDate, LocalDate.now());
        String text = "현재 기준 주차 offset: " + offset + "\n\n"
                + MealOrderCalculator.makeNotificationText(g1, g2, g3, offset);
        previewText.setText(text);
    }

    private int readClassCount(EditText input, String label) {
        int value = safeParse(input, -1);
        if (value < 1 || value > 30) {
            Toast.makeText(this, label + " 반 수는 1~30 사이로 입력하세요.", Toast.LENGTH_SHORT).show();
            return -1;
        }
        return value;
    }

    private int safeParse(EditText input, int defaultValue) {
        if (input == null) return defaultValue;
        try {
            String raw = input.getText().toString().trim();
            if (raw.isEmpty()) return defaultValue;
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    private EditText makeNumberInput(int value) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setSingleLine(true);
        input.setText(String.valueOf(value));
        input.setTextSize(18);
        input.setPadding(dp(12), dp(8), dp(12), dp(8));
        return input;
    }

    private TextView makeLabel(String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(14);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(14), 0, dp(4));
        return label;
    }

    private TextView makeBoxText(String text) {
        TextView box = new TextView(this);
        box.setText(text);
        box.setTextSize(18);
        box.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.setBackgroundColor(0xFFEFEFEF);
        return box;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private LinearLayout.LayoutParams matchWrapWithTopMargin(int marginDp) {
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(marginDp);
        return params;
    }

    private String formatTime(LocalTime time) {
        return String.format(Locale.KOREA, "%02d:%02d", time.getHour(), time.getMinute());
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
        }
    }
}
