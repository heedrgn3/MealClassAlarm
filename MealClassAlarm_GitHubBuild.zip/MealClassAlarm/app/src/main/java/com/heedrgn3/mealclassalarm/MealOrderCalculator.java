package com.heedrgn3.mealclassalarm;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class MealOrderCalculator {
    private MealOrderCalculator() {}

    public static int getWeekOffset(LocalDate startDate, LocalDate today) {
        long weeks = ChronoUnit.WEEKS.between(startDate, today);
        return (int) Math.max(0, weeks);
    }

    public static int rotatedClassNumber(int originalClassNumber, int weekOffset, int maxClassCount) {
        return ((originalClassNumber - 1 + weekOffset) % maxClassCount) + 1;
    }

    public static List<List<Integer>> getMealGroups(int maxClassCount, int weekOffset) {
        List<List<Integer>> groups = new ArrayList<>();
        if (maxClassCount <= 0) return groups;

        List<Integer> rotated = new ArrayList<>();
        for (int i = 1; i <= maxClassCount; i++) {
            rotated.add(rotatedClassNumber(i, weekOffset, maxClassCount));
        }

        for (int i = 0; i < rotated.size(); i += 3) {
            int end = Math.min(i + 3, rotated.size());
            groups.add(new ArrayList<>(rotated.subList(i, end)));
        }
        return groups;
    }

    public static String formatGroups(List<List<Integer>> groups) {
        List<String> groupTexts = new ArrayList<>();
        for (List<Integer> group : groups) {
            List<String> numbers = new ArrayList<>();
            for (Integer number : group) {
                numbers.add(String.valueOf(number));
            }
            groupTexts.add(join(numbers, ","));
        }
        return join(groupTexts, " / ");
    }

    public static String makeNotificationText(
            int grade1Count,
            int grade2Count,
            int grade3Count,
            int weekOffset
    ) {
        String g1 = formatGroups(getMealGroups(grade1Count, weekOffset));
        String g2 = formatGroups(getMealGroups(grade2Count, weekOffset));
        String g3 = formatGroups(getMealGroups(grade3Count, weekOffset));

        return "1학년: " + g1 + "\n"
                + "2학년: " + g2 + "\n"
                + "3학년: " + g3;
    }

    private static String join(List<String> values, String separator) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) builder.append(separator);
            builder.append(values.get(i));
        }
        return builder.toString();
    }
}
