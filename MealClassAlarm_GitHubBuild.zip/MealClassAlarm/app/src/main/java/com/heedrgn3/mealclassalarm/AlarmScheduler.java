package com.heedrgn3.mealclassalarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class AlarmScheduler {
    private static final int ALARM_REQUEST_CODE = 1303;

    private AlarmScheduler() {}

    public static void scheduleNext(Context context) {
        if (!AppPrefs.getBoolean(context, AppPrefs.KEY_ALARM_ENABLED, false)) {
            cancel(context);
            return;
        }

        int targetDay = AppPrefs.getInt(context, AppPrefs.KEY_ALARM_DAY_OF_WEEK, 1);
        int hour = AppPrefs.getInt(context, AppPrefs.KEY_ALARM_HOUR, 8);
        int minute = AppPrefs.getInt(context, AppPrefs.KEY_ALARM_MINUTE, 0);

        ZonedDateTime now = ZonedDateTime.now();
        ZonedDateTime triggerTime = nextTriggerTime(now, targetDay, hour, minute);
        long triggerAtMillis = triggerTime.toInstant().toEpochMilli();

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pendingIntent = makePendingIntent(context);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent);
        }
    }

    public static void cancel(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.cancel(makePendingIntent(context));
        }
    }

    private static ZonedDateTime nextTriggerTime(ZonedDateTime now, int targetDayOfWeek, int hour, int minute) {
        LocalTime targetTime = LocalTime.of(hour, minute);
        int today = now.getDayOfWeek().getValue(); // 1=Mon ... 7=Sun
        int daysUntil = (targetDayOfWeek - today + 7) % 7;

        ZonedDateTime candidate = ZonedDateTime.of(
                now.toLocalDate(),
                targetTime,
                ZoneId.systemDefault()
        ).plusDays(daysUntil);

        if (!candidate.isAfter(now)) {
            candidate = candidate.plusDays(7);
        }
        return candidate;
    }

    private static PendingIntent makePendingIntent(Context context) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction("com.heedrgn3.mealclassalarm.SHOW_WEEKLY_NOTIFICATION");
        return PendingIntent.getBroadcast(
                context,
                ALARM_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }
}
