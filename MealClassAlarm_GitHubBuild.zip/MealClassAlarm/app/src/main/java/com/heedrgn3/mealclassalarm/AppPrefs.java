package com.heedrgn3.mealclassalarm;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDate;

public class AppPrefs {
    private static final String PREF_NAME = "meal_class_alarm_prefs";

    public static final String KEY_GRADE_1_COUNT = "grade_1_count";
    public static final String KEY_GRADE_2_COUNT = "grade_2_count";
    public static final String KEY_GRADE_3_COUNT = "grade_3_count";
    public static final String KEY_START_EPOCH_DAY = "start_epoch_day";
    public static final String KEY_ALARM_DAY_OF_WEEK = "alarm_day_of_week"; // 1=Mon ... 7=Sun
    public static final String KEY_ALARM_HOUR = "alarm_hour";
    public static final String KEY_ALARM_MINUTE = "alarm_minute";
    public static final String KEY_ALARM_ENABLED = "alarm_enabled";

    private AppPrefs() {}

    public static SharedPreferences get(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static int getInt(Context context, String key, int defaultValue) {
        return get(context).getInt(key, defaultValue);
    }

    public static long getLong(Context context, String key, long defaultValue) {
        return get(context).getLong(key, defaultValue);
    }

    public static boolean getBoolean(Context context, String key, boolean defaultValue) {
        return get(context).getBoolean(key, defaultValue);
    }

    public static void saveSettings(
            Context context,
            int grade1Count,
            int grade2Count,
            int grade3Count,
            LocalDate startDate,
            int alarmDayOfWeek,
            int alarmHour,
            int alarmMinute,
            boolean enabled
    ) {
        get(context).edit()
                .putInt(KEY_GRADE_1_COUNT, grade1Count)
                .putInt(KEY_GRADE_2_COUNT, grade2Count)
                .putInt(KEY_GRADE_3_COUNT, grade3Count)
                .putLong(KEY_START_EPOCH_DAY, startDate.toEpochDay())
                .putInt(KEY_ALARM_DAY_OF_WEEK, alarmDayOfWeek)
                .putInt(KEY_ALARM_HOUR, alarmHour)
                .putInt(KEY_ALARM_MINUTE, alarmMinute)
                .putBoolean(KEY_ALARM_ENABLED, enabled)
                .apply();
    }

    public static LocalDate getStartDate(Context context) {
        long today = LocalDate.now().toEpochDay();
        long epochDay = getLong(context, KEY_START_EPOCH_DAY, today);
        return LocalDate.ofEpochDay(epochDay);
    }
}
